=== WooCommerce Custom Payment Gateway ===
Contributors: ala_eddin_eltai, secpaid_ltd
Tags: woocommerce, payment gateway, woocommerce extension, custom payment
Requires at least: 4.0
Tested up to: 6.7
Stable tag: 1.4.0
Requires PHP: 7.0
WC requires at least: 3.0
WC tested up to: 9.4
Requires Plugins: woocommerce
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin is essential for capturing every possible sale by providing a custom payment gateway option.